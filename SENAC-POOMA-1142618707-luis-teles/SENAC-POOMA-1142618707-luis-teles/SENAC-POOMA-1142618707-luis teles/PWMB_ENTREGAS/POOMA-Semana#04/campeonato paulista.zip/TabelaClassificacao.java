public class TabelaClassificacao {
    private Time time;
    private int pontos;
    private int partidasJogadas;
    private int vitorias;
    private int empates;
    private int derrotas;
    private int golsMarcados;
    private int golsSofridos;

    public TabelaClassificacao(Time time) {
        this.time = time;
    }

    // Implemente métodos para atualizar os valores da tabela de classificação
}
